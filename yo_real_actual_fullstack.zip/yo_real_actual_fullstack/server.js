const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const Database = require("better-sqlite3");
const { nanoid } = require("nanoid");
const path = require("path");

const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "dev-token";
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data.sqlite");

const app = express();
const db = new Database(DB_PATH);

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS submissions (
    id TEXT PRIMARY KEY,
    coachee_name TEXT NOT NULL,
    coach_name TEXT NOT NULL,
    process_stage TEXT NOT NULL,
    completed_at TEXT,
    average_score REAL,
    answers_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE INDEX IF NOT EXISTS idx_submissions_created_at
  ON submissions(created_at);
`);

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(cors());
app.use(morgan("dev"));
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

function requireAdmin(req, res, next) {
  const token = req.headers["x-admin-token"];
  if (token !== ADMIN_TOKEN) {
    return res.status(401).json({ error: "No autorizado" });
  }
  next();
}

function calculateAverageScore(answers) {
  const values = Object.values(answers || {})
    .filter((item) => item && item.type === "scale" && item.value !== "")
    .map((item) => Number(item.value))
    .filter((n) => !Number.isNaN(n));

  if (!values.length) return null;
  return Number((values.reduce((a, b) => a + b, 0) / values.length).toFixed(2));
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "yo-real-actual", timestamp: new Date().toISOString() });
});

app.post("/api/submissions", (req, res) => {
  const {
    coacheeName,
    coachName,
    processStage,
    completedAt,
    answers
  } = req.body || {};

  if (!coacheeName || !coachName || !processStage || !answers || typeof answers !== "object") {
    return res.status(400).json({
      error: "Faltan campos obligatorios: coacheeName, coachName, processStage, answers."
    });
  }

  const id = nanoid(12);
  const averageScore = calculateAverageScore(answers);

  const stmt = db.prepare(`
    INSERT INTO submissions (
      id,
      coachee_name,
      coach_name,
      process_stage,
      completed_at,
      average_score,
      answers_json
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run(
    id,
    coacheeName,
    coachName,
    processStage,
    completedAt || null,
    averageScore,
    JSON.stringify(answers)
  );

  res.status(201).json({
    ok: true,
    id,
    averageScore
  });
});

app.get("/api/submissions", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT
      id,
      coachee_name AS coacheeName,
      coach_name AS coachName,
      process_stage AS processStage,
      completed_at AS completedAt,
      average_score AS averageScore,
      created_at AS createdAt
    FROM submissions
    ORDER BY created_at DESC
    LIMIT 100
  `).all();

  res.json({ items: rows });
});

app.get("/api/submissions/:id", requireAdmin, (req, res) => {
  const row = db.prepare(`
    SELECT
      id,
      coachee_name AS coacheeName,
      coach_name AS coachName,
      process_stage AS processStage,
      completed_at AS completedAt,
      average_score AS averageScore,
      answers_json AS answersJson,
      created_at AS createdAt
    FROM submissions
    WHERE id = ?
  `).get(req.params.id);

  if (!row) return res.status(404).json({ error: "Respuesta no encontrada" });

  res.json({
    ...row,
    answers: JSON.parse(row.answersJson || "{}"),
    answersJson: undefined
  });
});

app.delete("/api/submissions/:id", requireAdmin, (req, res) => {
  const result = db.prepare("DELETE FROM submissions WHERE id = ?").run(req.params.id);
  res.json({ ok: true, deleted: result.changes });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Yo Real-Actual app running on http://localhost:${PORT}`);
});