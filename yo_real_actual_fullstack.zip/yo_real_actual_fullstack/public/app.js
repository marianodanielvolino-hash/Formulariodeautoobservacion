const DRAFT_KEY = "yo_real_actual_draft_v1";

const sections = [
  {
    id: "pulso",
    title: "Pulso inicial del Yo Real-Actual",
    description: "Primera foto de satisfacción, energía y estado interior.",
    open: true,
    questions: [
      { id: "q1", type: "scale", domain: "Satisfacción general", required: true, text: "Hoy, en una escala del 1 al 10, ¿qué nivel de satisfacción general sentís con tu vida?" },
      { id: "q2", type: "textarea", required: true, text: "¿Qué datos concretos de tu vida actual explican ese número?" },
      { id: "q3", type: "textarea", required: true, text: "¿Cómo te sentís la mayor parte del tiempo?" },
      { id: "q4", type: "textarea", text: "¿Qué te hace feliz hoy, aunque sea simple o cotidiano?" },
      { id: "q5", type: "textarea", required: true, text: "¿Qué sentís que está pidiendo atención ahora mismo?" }
    ]
  },
  {
    id: "dominios",
    title: "Dominios de vida",
    description: "Radiografía concreta de las áreas principales de la vida.",
    questions: [
      { id: "work", type: "domain", domain: "Trabajo / profesión", text: "Trabajo / profesión" },
      { id: "money", type: "domain", domain: "Dinero / seguridad", text: "Dinero / seguridad" },
      { id: "health", type: "domain", domain: "Salud / cuerpo", text: "Salud / cuerpo" },
      { id: "food", type: "domain", domain: "Alimentación / cuidado", text: "Alimentación / cuidado" },
      { id: "children", type: "children", text: "Vínculo con hijos/as" },
      { id: "partner_family", type: "domain", domain: "Pareja / familia", text: "Pareja / familia" },
      { id: "friends", type: "domain", domain: "Amistades / red de apoyo", text: "Amistades / red de apoyo" },
      { id: "purpose", type: "domain", domain: "Propósito / sentido", text: "Propósito / sentido" },
      { id: "spiritual", type: "domain", domain: "Espiritualidad / vida interior", text: "Espiritualidad / vida interior" },
      { id: "time", type: "domain", domain: "Tiempo / hábitos", text: "Tiempo / hábitos" },
      { id: "rest", type: "domain", domain: "Descanso / disfrute", text: "Descanso / disfrute" }
    ]
  },
  {
    id: "bienestar",
    title: "Bienestar interior",
    description: "Conciencia emocional, diálogo mental, centro interno y compasión.",
    questions: [
      { id: "q30", type: "scale", domain: "Bienestar interior", required: true, text: "En una escala del 1 al 10, ¿cuánto tiempo y atención real dedicás a tu bienestar interior?" },
      { id: "q31", type: "textarea", required: true, text: "¿Sos consciente de tus emociones? ¿Cómo te das cuenta de lo que estás sintiendo?" },
      { id: "q32", type: "textarea", required: true, text: "¿Sos consciente del diálogo que generan tus pensamientos? Describí cómo te hablás internamente." },
      { id: "q33", type: "textarea", text: "¿Reflexionaste alguna vez sobre la capacidad creativa de tu mente? ¿Qué suele crear tu mente: posibilidades, amenazas, exigencias, calma, conflictos?" },
      { id: "q34", type: "textarea", required: true, text: "¿Cuáles son tus cinco principales miedos actuales?" },
      { id: "q35", type: "textarea", required: true, text: "¿A qué estás apegado hoy? Pueden ser personas, roles, imágenes, resultados, hábitos, certezas o formas de control." },
      { id: "q36", type: "textarea", required: true, text: "¿Qué sentís que te limita en tu vida actual?" },
      { id: "q37", type: "textarea", required: true, text: "¿Qué cosas te sacan de tu centro?" },
      { id: "q38", type: "textarea", required: true, text: "¿Cómo reaccionás frente a las críticas?" }
    ]
  },
  {
    id: "limites",
    title: "Límites, perdón y expresión emocional",
    description: "Cómo el Yo Real-Actual se cuida, se expresa y se vincula con el error.",
    questions: [
      { id: "q40", type: "scale", domain: "Límites personales", required: true, text: "En una escala del 1 al 10, ¿qué tan fácil te resulta poner límites?" },
      { id: "q41", type: "textarea", required: true, text: "¿Dónde te cuesta poner límites hoy?" },
      { id: "q42", type: "textarea", text: "¿Qué costo estás pagando por no poner esos límites?" },
      { id: "q43", type: "scale", domain: "Autocompasión", required: true, text: "En una escala del 1 al 10, ¿qué tan compasivo sos con vos mismo?" },
      { id: "q44", type: "textarea", required: true, text: "¿Te amás a vos mismo? Respondé desde conductas concretas, no desde una idea abstracta." },
      { id: "q45", type: "textarea", required: true, text: "¿Te perdonás a vos mismo? ¿Qué te cuesta perdonarte?" },
      { id: "q46", type: "textarea", text: "¿Te resulta fácil perdonar a los demás? ¿En qué casos se vuelve difícil?" },
      { id: "q47", type: "textarea", required: true, text: "¿Te permitís expresar tus sentimientos? ¿Cuáles sí y cuáles no?" },
      { id: "q48", type: "textarea", text: "¿Sos compasivo con los demás? ¿Qué diferencia hay entre tu compasión hacia otros y hacia vos?" }
    ]
  },
  {
    id: "patrones",
    title: "Patrones actuales y automatismos",
    description: "Lo que se repite, lo que se evita y lo que dirige desde abajo.",
    questions: [
      { id: "q50", type: "textarea", required: true, text: "¿Qué comportamientos tuyos se repiten aunque después no te gusten sus consecuencias?" },
      { id: "q51", type: "textarea", required: true, text: "¿En qué situaciones reaccionás en automático en lugar de elegir conscientemente?" },
      { id: "q52", type: "textarea", text: "¿Qué conversación venís postergando?" },
      { id: "q53", type: "textarea", required: true, text: "¿Qué decisión sabés que en algún momento vas a tener que tomar?" },
      { id: "q54", type: "textarea", text: "¿Qué beneficio oculto puede tener para vos seguir igual?" },
      { id: "q55", type: "textarea", text: "¿Qué versión de vos aparece frente a los demás y qué versión queda escondida?" }
    ]
  },
  {
    id: "brecha",
    title: "Puente hacia el Yo Ideal",
    description: "No define todavía el ideal completo: identifica la brecha que empieza a aparecer.",
    questions: [
      { id: "q60", type: "textarea", required: true, text: "Después de responder este formulario, ¿qué descubrimiento aparece con más fuerza sobre tu Yo Real-Actual?" },
      { id: "q61", type: "textarea", required: true, text: "¿Qué distancia empezás a ver entre quien estás siendo hoy y quien te gustaría llegar a ser?" },
      { id: "q62", type: "checkbox", required: true, text: "¿Qué áreas piden atención prioritaria?", options: ["Trabajo / profesión", "Dinero", "Salud", "Cuerpo", "Alimentación", "Hijos/as", "Pareja", "Familia", "Amistades", "Emociones", "Propósito", "Espiritualidad", "Hábitos", "Tiempo", "Descanso", "Límites", "Miedos", "Otra"] },
      { id: "q63", type: "textarea", required: true, text: "¿Qué tres temas querés trabajar con mayor profundidad durante el proceso?" },
      { id: "q64", type: "textarea", required: true, text: "¿Qué compromiso inicial asumís para observarte sin justificarte ni escaparte hacia el ideal?" }
    ]
  }
];

const domainQuestions = [
  { suffix: "score", type: "scale", label: "En una escala del 1 al 10, ¿cómo está hoy este dominio?" },
  { suffix: "state", type: "textarea", label: "¿Cómo está hoy, concretamente? Describí hechos, no interpretaciones generales." },
  { suffix: "pattern", type: "textarea", label: "¿Qué patrón tuyo se repite en este dominio?" },
  { suffix: "need", type: "textarea", label: "¿Qué necesita atención, orden o corrección en este dominio?" }
];

const childQuestions = [
  { suffix: "name", type: "input", label: "Nombre del hijo/a" },
  { suffix: "score", type: "scale", label: "En una escala del 1 al 10, ¿cómo evaluás hoy este vínculo?" },
  { suffix: "valuable", type: "textarea", label: "¿Qué es lo más valioso de este vínculo?" },
  { suffix: "need", type: "textarea", label: "¿Qué necesita más presencia, cuidado o reparación?" },
  { suffix: "pattern", type: "textarea", label: "¿Qué patrón tuyo aparece con frecuencia en este vínculo?" },
  { suffix: "gesture", type: "textarea", label: "¿Qué gesto concreto podrías hacer este mes para fortalecerlo?" }
];

let childCount = 0;

function escapeHtml(str) {
  return String(str).replace(/[&<>'"]/g, (tag) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    "\"": "&quot;"
  }[tag]));
}

function renderScale(name, domain) {
  return `<div class="scale" role="radiogroup" data-domain="${escapeHtml(domain)}">
    ${Array.from({ length: 10 }, (_, i) => i + 1).map(num => `
      <label>
        <input type="radio" name="${name}" value="${num}" data-track="true" data-scale="true" data-domain="${escapeHtml(domain)}" />
        <span>${num}</span>
      </label>
    `).join("")}
  </div>`;
}

function renderField(q) {
  if (q.type === "scale") return renderScale(q.id, q.domain || q.text);

  if (q.type === "checkbox") {
    return `<div class="choice-list">${q.options.map(opt => `
      <label><input type="checkbox" name="${q.id}" value="${escapeHtml(opt)}" data-track="true" /> ${escapeHtml(opt)}</label>
    `).join("")}</div>`;
  }

  if (q.type === "input") {
    return `<input type="text" name="${q.id}" data-track="true" placeholder="Respuesta breve..." />`;
  }

  return `<textarea name="${q.id}" data-track="true" placeholder="Escribí con ejemplos concretos. ¿Qué pasa, cuándo pasa, con qué frecuencia y qué impacto tiene?"></textarea>`;
}

function renderDomain(q) {
  return `<div class="domain-card">
    <h3>${q.text}</h3>
    ${domainQuestions.map(dq => {
      const id = `${q.id}_${dq.suffix}`;
      return `<div class="question" data-question="${id}" data-label="${escapeHtml(q.text + " · " + dq.label)}">
        <div class="question-header">
          <div class="question-title">${dq.label}</div>
          ${dq.suffix === "score" ? '<span class="tag">Escala</span>' : ""}
        </div>
        ${renderField({ id, type: dq.type, domain: q.domain, text: dq.label })}
      </div>`;
    }).join("")}
  </div>`;
}

function renderChildrenSection() {
  return `<div class="question">
    <div class="question-header">
      <div>
        <div class="question-title">Vínculos con hijos/as</div>
        <div class="helper">Agregar un bloque por cada hijo/a. Si no corresponde, dejar sin completar.</div>
      </div>
      <button type="button" class="secondary" id="addChildBtn">Agregar hijo/a</button>
    </div>
    <div id="childrenContainer"></div>
  </div>`;
}

function renderQuestion(q) {
  if (q.type === "domain") return renderDomain(q);
  if (q.type === "children") return renderChildrenSection();

  return `<div class="question" data-question="${q.id}" data-label="${escapeHtml(q.text)}">
    <div class="question-header">
      <div class="question-title">${q.text}</div>
      ${q.required ? '<span class="tag">Clave</span>' : ""}
    </div>
    ${renderField(q)}
  </div>`;
}

function renderForm() {
  const form = document.getElementById("selfObservationForm");
  const navGrid = document.getElementById("navGrid");

  navGrid.innerHTML = sections.map((section, index) => `
    <a href="#${section.id}">${index + 1}. ${section.title}</a>
  `).join("");

  form.innerHTML = sections.map((section, index) => `
    <details class="section-card" id="${section.id}" ${section.open ? "open" : ""}>
      <summary>
        <div class="section-title">
          <div class="section-number">${index + 1}</div>
          <div>
            <h2>${section.title}</h2>
            <p>${section.description}</p>
          </div>
        </div>
        <div class="chevron">⌄</div>
      </summary>
      <div class="questions">${section.questions.map(renderQuestion).join("")}</div>
    </details>
  `).join("");

  document.getElementById("addChildBtn")?.addEventListener("click", () => addChildBlock(true));

  childCount = 0;
  addChildBlock(false);
  bindInputs();
  updateAll();
}

function addChildBlock(shouldFocus = true) {
  const container = document.getElementById("childrenContainer");
  if (!container) return;

  childCount += 1;
  const idx = childCount;

  const block = document.createElement("div");
  block.className = "child-block";
  block.dataset.childIndex = String(idx);

  block.innerHTML = `<h3>Hijo/a ${idx}</h3>
    ${childQuestions.map(q => {
      const id = `child_${idx}_${q.suffix}`;
      return `<div class="question" data-question="${id}" data-label="Hijo/a ${idx} · ${escapeHtml(q.label)}">
        <div class="question-header">
          <div class="question-title">${q.label}</div>
          ${q.suffix === "score" ? '<span class="tag">Escala</span>' : ""}
        </div>
        ${renderField({ id, type: q.type, domain: `Hijo/a ${idx}`, text: q.label })}
      </div>`;
    }).join("")}
    <button type="button" class="ghost remove-child">Eliminar este bloque</button>`;

  container.appendChild(block);

  block.querySelector(".remove-child").addEventListener("click", () => {
    block.remove();
    updateAll();
  });

  bindInputs();
  updateAll();

  if (shouldFocus) {
    const firstInput = block.querySelector("input[type='text'], textarea");
    if (firstInput) firstInput.focus();
  }
}

function bindInputs() {
  document.querySelectorAll("input[data-track='true'], textarea[data-track='true']").forEach(el => {
    el.removeEventListener("input", updateAll);
    el.removeEventListener("change", updateAll);
    el.addEventListener("input", updateAll);
    el.addEventListener("change", updateAll);
  });
}

function getFieldsByName(name) {
  return Array.from(document.getElementsByName(name));
}

function getAllQuestionNames() {
  const names = [];
  document.querySelectorAll("input[data-track='true'], textarea[data-track='true']").forEach(el => {
    if (el.name && !names.includes(el.name)) names.push(el.name);
  });
  return names;
}

function getAnswer(name) {
  const fields = getFieldsByName(name);
  if (!fields.length) return "";

  const type = fields[0].type;

  if (type === "radio") {
    const checked = fields.find(f => f.checked);
    return checked ? checked.value : "";
  }

  if (type === "checkbox") {
    return fields.filter(f => f.checked).map(f => f.value);
  }

  return fields[0].value || "";
}

function getQuestionLabel(name) {
  const fields = getFieldsByName(name);
  const wrapper = fields[0]?.closest(".question");
  return wrapper?.dataset?.label || name;
}

function collectAnswers() {
  const answers = {};

  getAllQuestionNames().forEach(name => {
    const value = getAnswer(name);
    const fields = getFieldsByName(name);
    const type = fields[0]?.dataset?.scale === "true" ? "scale" : fields[0]?.type || "text";
    const domain = fields[0]?.dataset?.domain || "";
    answers[name] = {
      label: getQuestionLabel(name),
      type,
      domain,
      value
    };
  });

  return answers;
}

function collectPayload() {
  return {
    coacheeName: document.getElementById("coacheeName").value.trim(),
    coachName: document.getElementById("coachName").value.trim(),
    processStage: document.getElementById("processStage").value.trim(),
    completedAt: document.getElementById("completedAt").value || null,
    answers: collectAnswers()
  };
}

function updateProgress() {
  const names = getAllQuestionNames();
  const answered = names.filter(name => {
    const value = getAnswer(name);
    return Array.isArray(value) ? value.length > 0 : String(value || "").trim().length > 0;
  }).length;

  const percent = names.length ? Math.round((answered / names.length) * 100) : 0;
  document.getElementById("progressBar").style.width = `${percent}%`;
  document.getElementById("progressText").textContent = `${percent}%`;
}

function getScaleScores() {
  return Array.from(document.querySelectorAll("input[data-scale='true']:checked"))
    .map(el => ({ domain: el.dataset.domain || el.name, value: Number(el.value) }))
    .filter(x => !Number.isNaN(x.value));
}

function updateCoachSummary() {
  const scores = getScaleScores();
  const avgEl = document.getElementById("avgScore");
  const lowEl = document.getElementById("lowDomains");
  const highEl = document.getElementById("highDomains");

  if (!scores.length) {
    avgEl.textContent = "—";
    lowEl.innerHTML = "<li>Completar escalas para calcular.</li>";
    highEl.innerHTML = "<li>Completar escalas para calcular.</li>";
    return;
  }

  const avg = scores.reduce((sum, s) => sum + s.value, 0) / scores.length;
  avgEl.textContent = avg.toFixed(1);

  lowEl.innerHTML = [...scores]
    .sort((a, b) => a.value - b.value)
    .slice(0, 4)
    .map(s => `<li>${escapeHtml(s.domain)}: ${s.value}/10</li>`)
    .join("");

  highEl.innerHTML = [...scores]
    .sort((a, b) => b.value - a.value)
    .slice(0, 4)
    .map(s => `<li>${escapeHtml(s.domain)}: ${s.value}/10</li>`)
    .join("");
}

function updateAll() {
  updateProgress();
  updateCoachSummary();
}

function saveDraft() {
  localStorage.setItem(DRAFT_KEY, JSON.stringify(collectPayload()));
  alert("Borrador guardado en este navegador.");
}

function loadDraft() {
  const raw = localStorage.getItem(DRAFT_KEY);
  if (!raw) return;

  try {
    const data = JSON.parse(raw);
    document.getElementById("coacheeName").value = data.coacheeName || "Pedro Thompson";
    document.getElementById("coachName").value = data.coachName || "Juan";
    document.getElementById("processStage").value = data.processStage || "Yo Real-Actual";
    document.getElementById("completedAt").value = data.completedAt || new Date().toISOString().slice(0, 10);

    const answers = data.answers || {};
    Object.entries(answers).forEach(([name, answer]) => {
      const fields = getFieldsByName(name);
      if (!fields.length) return;

      if (fields[0].type === "radio") {
        fields.forEach(f => f.checked = String(f.value) === String(answer.value));
      } else if (fields[0].type === "checkbox") {
        fields.forEach(f => f.checked = Array.isArray(answer.value) && answer.value.includes(f.value));
      } else {
        fields[0].value = answer.value || "";
      }
    });

    updateAll();
  } catch (error) {
    console.warn("No se pudo cargar el borrador", error);
  }
}

function clearForm() {
  if (!confirm("¿Seguro que querés limpiar las respuestas?")) return;

  localStorage.removeItem(DRAFT_KEY);

  document.querySelectorAll("input[data-track='true'], textarea[data-track='true']").forEach(el => {
    if (el.type === "radio" || el.type === "checkbox") el.checked = false;
    else el.value = "";
  });

  updateAll();
}

function exportJson() {
  const data = collectPayload();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const cleanName = (data.coacheeName || "coachee").toLowerCase().replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "");
  a.href = url;
  a.download = `yo-real-actual-${cleanName || "coachee"}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function submitToBackend() {
  const payload = collectPayload();

  if (!payload.coacheeName || !payload.coachName || !payload.processStage) {
    alert("Faltan datos iniciales obligatorios.");
    return;
  }

  const response = await fetch("/api/submissions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const result = await response.json();

  if (!response.ok) {
    alert(result.error || "No se pudo guardar la respuesta.");
    return;
  }

  localStorage.removeItem(DRAFT_KEY);
  alert(`Respuesta guardada en backend. ID: ${result.id}`);
}

async function loadSubmissions() {
  const token = document.getElementById("adminToken").value;
  const results = document.getElementById("adminResults");

  const response = await fetch("/api/submissions", {
    headers: { "x-admin-token": token }
  });

  const data = await response.json();

  if (!response.ok) {
    results.innerHTML = `<div class="admin-card">${escapeHtml(data.error || "Error al consultar respuestas.")}</div>`;
    return;
  }

  if (!data.items.length) {
    results.innerHTML = `<div class="admin-card">Todavía no hay respuestas guardadas.</div>`;
    return;
  }

  results.innerHTML = data.items.map(item => `
    <div class="admin-card">
      <strong>${escapeHtml(item.coacheeName)}</strong><br />
      Coach: ${escapeHtml(item.coachName)}<br />
      Etapa: ${escapeHtml(item.processStage)}<br />
      Promedio: ${item.averageScore ?? "—"}<br />
      Fecha de carga: ${escapeHtml(item.createdAt)}<br />
      ID: <code>${escapeHtml(item.id)}</code>
    </div>
  `).join("");
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("completedAt").value = new Date().toISOString().slice(0, 10);

  renderForm();
  loadDraft();

  document.getElementById("saveDraftBtn").addEventListener("click", saveDraft);
  document.getElementById("exportBtn").addEventListener("click", exportJson);
  document.getElementById("submitBtn").addEventListener("click", submitToBackend);
  document.getElementById("clearBtn").addEventListener("click", clearForm);
  document.getElementById("loadSubmissionsBtn").addEventListener("click", loadSubmissions);

  updateAll();
});