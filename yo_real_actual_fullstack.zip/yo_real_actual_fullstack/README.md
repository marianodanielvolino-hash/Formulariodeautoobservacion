# Yo Real-Actual · Fullstack

Aplicación web con:

- Frontend HTML/CSS/JS.
- Backend Node.js + Express.
- Base de datos SQLite local.
- Guardado de borrador en navegador.
- Envío definitivo al backend.
- Panel simple de administración protegido por token.

## Requisitos

- Node.js 18 o superior.

## Instalación

```bash
npm install
```

## Configuración

Copiar el archivo de ejemplo:

```bash
cp .env.example .env
```

Editar el token de administración:

```bash
ADMIN_TOKEN=un-token-seguro
PORT=3000
```

## Ejecución

```bash
npm start
```

Abrir:

```text
http://localhost:3000
```

## Endpoints backend

### Health check

```http
GET /api/health
```

### Guardar respuesta

```http
POST /api/submissions
Content-Type: application/json
```

Body esperado:

```json
{
  "coacheeName": "Pedro Thompson",
  "coachName": "Juan",
  "processStage": "Yo Real-Actual",
  "completedAt": "2026-05-13",
  "answers": {}
}
```

### Listar respuestas

```http
GET /api/submissions
x-admin-token: ADMIN_TOKEN
```

### Ver respuesta por ID

```http
GET /api/submissions/:id
x-admin-token: ADMIN_TOKEN
```

### Eliminar respuesta

```http
DELETE /api/submissions/:id
x-admin-token: ADMIN_TOKEN
```

## Base de datos

Se crea automáticamente el archivo:

```text
data.sqlite
```

Tabla principal:

```sql
submissions
```

Campos:

- id
- coachee_name
- coach_name
- process_stage
- completed_at
- average_score
- answers_json
- created_at

## Próximo nivel recomendado

Para producción real:

- autenticación de usuarios;
- consentimiento informado;
- cifrado de respuestas sensibles;
- backups automáticos;
- hosting con HTTPS;
- separación de roles: coach / administrador;
- exportación PDF del diagnóstico.